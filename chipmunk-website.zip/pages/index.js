import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";
import { motion } from "framer-motion";

export default function ChipmunkPage() {
  return (
    <div className="bg-yellow-50 text-brown-900 font-sans min-h-screen">
      {/* Hero Section */}
      <section className="text-center py-20 px-4 bg-gradient-to-b from-yellow-100 to-yellow-200">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
          <img src="/IMG_1538.JPG" alt="Happy Chipmunk" width={200} height={200} className="mx-auto" />
          <h1 className="text-5xl font-bold mt-6">CHIPMUNK</h1>
          <p className="text-xl mt-2">$MUNK – The Cheekiest Coin on the Chain!</p>
          <Button className="mt-6 bg-brown-600 text-white px-6 py-3 rounded-2xl hover:bg-brown-700">Buy Now</Button>
        </motion.div>
      </section>

      {/* About Section */}
      <section className="py-16 px-6 text-center">
        <h2 className="text-3xl font-bold mb-4">What is CHIPMUNK?</h2>
        <p className="max-w-3xl mx-auto text-lg">
          $MUNK is more than just a memecoin – it’s a squirrelly movement. Bursting with energy and a
          cheeky charm, CHIPMUNK is here to scamper through the blockchain and leave a trail of nuts
          (and gains) behind!
        </p>
      </section>

      {/* Tokenomics Section */}
      <section className="bg-yellow-100 py-16 px-6">
        <h2 className="text-3xl font-bold text-center mb-8">Tokenomics</h2>
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          <Card className="rounded-2xl shadow-md">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold">Total Supply</h3>
              <p className="text-lg mt-2">1,000,000,000 $MUNK</p>
            </CardContent>
          </Card>
          <Card className="rounded-2xl shadow-md">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold">Buy Tax</h3>
              <p className="text-lg mt-2">1%</p>
            </CardContent>
          </Card>
          <Card className="rounded-2xl shadow-md">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold">Sell Tax</h3>
              <p className="text-lg mt-2">1%</p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* How to Buy Section */}
      <section className="py-16 px-6">
        <h2 className="text-3xl font-bold text-center mb-8">How to Buy</h2>
        <ol className="max-w-2xl mx-auto list-decimal list-inside text-left text-lg space-y-4">
          <li>Download a crypto wallet like Phantom or MetaMask.</li>
          <li>Get some SOL or ETH (depending on chain).</li>
          <li>Go to your favorite DEX (Uniswap, Raydium, etc.).</li>
          <li>Swap for $MUNK using our official contract address.</li>
        </ol>
      </section>

      {/* Roadmap Section */}
      <section className="bg-yellow-200 py-16 px-6">
        <h2 className="text-3xl font-bold text-center mb-8">Roadmap</h2>
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          <Card className="rounded-2xl shadow-md">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold">Phase 1</h3>
              <ul className="list-disc list-inside mt-2 text-lg">
                <li>Launch Website & Token</li>
                <li>1000+ Holders</li>
                <li>CMC + CG Listings</li>
              </ul>
            </CardContent>
          </Card>
          <Card className="rounded-2xl shadow-md">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold">Phase 2</h3>
              <ul className="list-disc list-inside mt-2 text-lg">
                <li>Community Competitions</li>
                <li>Major Influencer Collabs</li>
                <li>DEX Partnerships</li>
              </ul>
            </CardContent>
          </Card>
          <Card className="rounded-2xl shadow-md">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold">Phase 3</h3>
              <ul className="list-disc list-inside mt-2 text-lg">
                <li>CHIPMUNK NFT Drop</li>
                <li>Bridge to Multiple Chains</li>
                <li>More Nutty Surprises</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer Section */}
      <footer className="text-center py-10 bg-yellow-100">
        <p className="text-md">&copy; 2025 CHIPMUNK ($MUNK). All rights reserved.</p>
        <div className="flex justify-center space-x-4 mt-4">
          <a href="#" className="text-brown-700 hover:text-brown-900">Twitter</a>
          <a href="#" className="text-brown-700 hover:text-brown-900">Telegram</a>
          <a href="#" className="text-brown-700 hover:text-brown-900">Buy $MUNK</a>
        </div>
      </footer>
    </div>
  );
}
